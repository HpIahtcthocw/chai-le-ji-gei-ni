# 无名件 · 参赛源码包

Aholo 全球 3D AI 黑客松参赛作品「无名件」的源代码（不含模型产物与媒体运行时）。

## 跑起来

```bash
npm install
cp .env.example .env.local   # 填 AHOLO_API_KEY
npm run dev -- -p 3100
```

- 拆件台（寄件端）：http://localhost:3100/live
- 收件拆件：http://localhost:3100/p/<码>（示例件 /p/lamp、/p/radio、/p/fan）
- 回信：http://localhost:3100/r/<码>

线上版本：https://chai-le-ji-gei-ni.vercel.app
成片：docs/demo/wumingjian-demo.mp4

## 没打进来的东西（体积原因）

- `public/items/`：三件真产物与现场生成件（GLB，约 130 MB），由 Aholo Lux3D 的 `imgTo3D` + `partSplit` 产出，任务号与下载地址见 `docs/项目报告书.md` 第四、八节。
- `public/mediapipe/`：MediaPipe HandLandmarker 的 wasm 与模型文件（约 36 MB），来自 MediaPipe 官方发布包。
- `node_modules/`、`.next/`、`.git/`：依赖与构建产物。
- 线上凭据只存在 `.env.local`（`AHOLO_API_KEY` / `AHOLO_REGION`），不入包。

## 主要文件

- `app/live/page.tsx`：拆件台（1995 窗口式工位 + 寄件单）
- `app/p/[code]/page.tsx`：收件拆件页
- `components/LockProto.tsx`：拆件舞台（七块独立 mesh、方向箭、撬痕、纸条、四档材质）
- `components/HandInput.tsx`：摄像头手势（捏合抓件、张手分解、握拳拼接）
- `app/api/gen`、`app/api/split`、`app/api/parcel`、`app/api/reply`：无状态生成与包裹码
- `docs/项目报告书.md` / `docs/项目报告书.pdf`：项目报告
- `docs/部署记录.md`：Aholo 任务号、部署与复现记录
